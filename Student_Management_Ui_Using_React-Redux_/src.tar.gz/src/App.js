import React from 'react'
import * as StudentAction from './redux/action'
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { Table,InputGroup, InputGroupAddon, Button, Input } from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';


import { relative } from 'path'

class App extends React.Component{
  constructor (props){
    super(props)
    this.state = {
      studentname:'',
      cgpa:'',
      college_code:'',            
      dob:'',
      location:''
    }
  }

changeHandler = e => {
  this.setState({[e.target.placeholder]: e.target.value})
}

submitHandler = e => {
  e.preventDefault()
  console.log(this.state)
}

componentDidMount(){
  // console.log("-- componentDidMount --")
  // console.log(this.setState({hello:"Welcome"}))
  this.props.StudentAction.getAllEmployee()
  // this.props.StudentAction.postEmployee()
  
}

static getDerivedStateFromProps(){
  // console.log("--- getDerivedStateFromProps ---")

}

componentDidUpdate(){
  // console.log("--- componentDidUpdate ---")
}

  render(){
    const {hello,a}=this.state;
    console.log("1-1-1-1", this.props)
    const student = this.props.getall
    // console.log("--- stunet --", student)
    {student && student.length >0 && student.map((stu) =>
      console.log("222222", stu)
    )}

    const {studentname,cgpa,college_code,dob,location}=this.state

    return(
      // <div>
      // <h1>{hello}</h1>
      // <A a={a}/>
      // </div>
      <div>
      
      <Table>
          <thead>
            <tr>
              <th>id</th>
              <th>studentname</th>
              <th>cgpa</th>
              <th>college_code</th>
              <th>dob</th>
              <th>location</th>   
            </tr>
          </thead>
            {student && student.length >0 && student.map((stu) =>
            <tbody>
            <tr>
              <td>{stu.id}</td> 
              <td>{stu.studentname}</td>  
              <td>{stu.cgpa}</td>
              <td>{stu.college_code}</td>
              <td>{stu.dob}</td>
              <td>{stu.location}</td> 
            </tr>
            </tbody>
              )}
        </Table>

        <form onSubmit={this.submitHandler}>
        <InputGroup>
        <InputGroupAddon addonType="prepend">@</InputGroupAddon>
        <Input placeholder="studentname" vale={studentname} onChange={this.changeHandler} />
        </InputGroup>

        <InputGroup>
        <InputGroupAddon addonType="prepend">@</InputGroupAddon>
        <Input placeholder="cgpa" value={cgpa} onChange={this.changeHandler} />
        </InputGroup>

        <InputGroup>
        <InputGroupAddon addonType="prepend">@</InputGroupAddon>
        <Input placeholder="college_code" value={college_code} onChange={this.changeHandler} />
        </InputGroup>

        <InputGroup>
        <InputGroupAddon addonType="prepend">@</InputGroupAddon>
        <Input placeholder="dob" value={dob} onChange={this.changeHandler} />
        </InputGroup>

        <InputGroup>
        <InputGroupAddon addonType="prepend">@</InputGroupAddon>
        <Input placeholder="location" value={location} onChange={this.changeHandler} />
        </InputGroup><br/>

        <Button  color="primary">Submit</Button>
        </form>

     </div>
    )
  }

}

class A extends React.Component{
  render(){
    const{a}=this.props
    return(
      <div>
      <h1>{a}</h1>
      </div>
    )
  }

}

function mapStateToProps(state, props){
  return{
    getall: state.StudentReducer.getallsucceeded,
    post: state.StudentReducer.success
  }
}

function mapDispatchToProps(dispatch){
  return{
    StudentAction: bindActionCreators(StudentAction, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(App)