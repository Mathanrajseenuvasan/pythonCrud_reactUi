import React,{Component} from 'react';

export default class Post extends Component{
    constructor (props){
        super(props)
        this.state = {
          response_code:'',
          http_method:'',
          name:'',            
          description:''
        }
      }
    render(){
        return(
            <div>
            <h1>Post Method</h1>
            <button onClick={()=>this.props.history.push('/')}>Previous</button><br /><br />
            </div>
        );
    }
}