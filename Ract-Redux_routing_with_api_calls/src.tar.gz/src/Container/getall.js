import React,{Component} from 'react';
import * as errorAction from '../Redux/actions'
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'


class Getall extends Component{

    componentDidMount(){
        console.log(" --- componentDidMount ---")

        this.props.errorAction.getallerror()
      }

    render(){
        console.log(" --- render ---", this.props)
        const error = this.props.getall
        return(
            <div>
            <h1>GetAll Method</h1>
            <table>
                <thead>
                <tr>
                    <th> id </th>
                    <th> response_code </th>
                    <th> http_method </th>
                    <th> name </th>
                    <th> description </th>
                </tr>
                </thead>

                <tbody>
                {error && error.data && error.data.results.map((err) =>
                <tr>
                    <td> {err.id} </td>
                    <td> {err.response_code} </td>
                    <td> {err.http_method} </td>
                    <td> {err.name} </td>
                    <td> {err.description} </td>
                </tr>
                )}
                </tbody>
            </table>
            <button onClick={()=>this.props.history.push('/post')}>Post</button>
            </div>
        );
    }
}

function mapStateToProps(state, props){
    return{
        getall: state.errorReducer.success
    }
    }

function mapDispatchToProps(dispatch){
    return{
        errorAction: bindActionCreators(errorAction, dispatch)
    }
    }

export default connect(mapStateToProps, mapDispatchToProps)(Getall)

