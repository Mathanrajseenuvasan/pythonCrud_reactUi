import * as types from './action-types';

export const getAllemployee = () => {
    return dispatch => {
        fetch('http://dummy.restapiexample.com/api/v1/employees')
            .then(response => response.json())
            .then(json => {
                dispatch({ type: types.GET_ALL_EMPLOYEES, payload: json });
            })
          
    }
}

export const getallerror = () => {
    console.log("get--- error ---")
    return dispatch => {
        fetch('http://localhost:7000/api/v1/error/')
        .then(response => response.json())
        .then(json => {
            console.log("-- data --", json)
            dispatch({type:types.GET_ALL_ERROR, payload:json});
        })
    }
}